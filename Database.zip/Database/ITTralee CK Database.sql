DROP TABLE Rating;
DROP TABLE Answer;
DROP TABLE Question;
DROP TABLE Category;
DROP TABLE Member;

CREATE TABLE Member(
Member_ID int not null,
Username varchar2(12),
MemberPassword varchar2(12),
Age number(3,0),
Email varchar2(40),
Gender varchar2(8),
Nationality varchar2(10),
Category_Of_Knowledge varchar2(255),
Newsletter VARCHAR2(1), --y or n
Type_Of_Member varchar2(10),
CONSTRAINT pk_member PRIMARY KEY (Member_ID));
ALTER TABLE MEMBER
ADD CONSTRAINT username_unique UNIQUE (USERNAME);



CREATE TABLE Category(
Category_ID int not null,
Category_Name varchar2(255),
CONSTRAINT pk_category PRIMARY KEY (Category_ID));


CREATE TABLE Question(
Question_ID int not null,
Member_ID int not null,
Category_ID int not null,
Question_Text varchar2(1000),
Question_Date DATE DEFAULT SYSDATE,
CONSTRAINT pk_question PRIMARY KEY (Question_ID),
CONSTRAINT fk_question_member FOREIGN KEY (Member_ID) REFERENCES Member,
CONSTRAINT fk_question_category FOREIGN KEY (Category_ID) REFERENCES Category);


CREATE TABLE Answer(
Answer_ID int not null,
Question_ID int not null,
Member_ID int not null,
Answer_Text varchar2(1000),
Answer_Date DATE DEFAULT SYSDATE,
CONSTRAINT pk_answer PRIMARY KEY (Answer_ID),
CONSTRAINT fk_answer_question FOREIGN KEY (Question_ID) REFERENCES Question,
CONSTRAINT fk_answer_Member FOREIGN KEY (Member_ID) REFERENCES Member);


CREATE TABLE Rating(
Rating_ID int not null,
Question_ID int not null,
Answer_ID int,
Rating int,
CONSTRAINT pk_rating PRIMARY KEY (Rating_ID),
CONSTRAINT fk_rating_question FOREIGN KEY (Question_ID) REFERENCES Question,
CONSTRAINT fk_rating_answer FOREIGN KEY (Answer_ID) REFERENCES Answer);

