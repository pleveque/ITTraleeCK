--length_question.sql--
--If question is less than 3 characters and greater than 1000 characters an error message will be given--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------
create or replace TRIGGER length_question
BEFORE INSERT OR UPDATE ON QUESTION
FOR EACH ROW
DECLARE

v_question_text QUESTION.QUESTION_TEXT%TYPE;
v_errorMessage1 varchar2(255);
v_errorMessage2 varchar2(255);


BEGIN

	v_question_text := :NEW.QUESTION_TEXT;
	v_errorMessage1 := 'Question must be greater than 3';
  v_errorMessage2 := 'Question must be inferior than 1000 characters';

	IF (NOT(LENGTH(v_question_text) >= 3))
	THEN
		Raise_application_error(-20000, v_errorMessage1);
  ELSE
    IF(NOT(LENGTH(v_question_text) <= 1000))
    THEN
    	Raise_application_error(-20001, v_errorMessage2);
    END IF;
	END IF;
END;