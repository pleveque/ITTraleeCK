--answerAlert.sql--
--When a questioned is answered the member who asked the question will be notified via email.--
--Author : Jerome O'connor--

--------------------------------------------------------------------------------------------


CREATE OR REPLACE TRIGGER answerAlert
AFTER INSERT
	ON Answer
	FOR EACH ROW
DECLARE
	mailhost VARCHAR2(255) := 'students.ittralee.ie';
	mail_conn utl_smtp.connection;
	id INTEGER;
	send_email VARCHAR(40);
	send_username VARCHAR(12);
BEGIN
	SELECT Member_ID INTO id FROM Question WHERE :new.Question_ID = Question_ID;
	SELECT Email INTO send_email FROM Member WHERE Member_ID = id;
	SELECT Username INTO send_username FROM Member WHERE Member_ID = id;
	IF (send_email is not null) THEN
		mail_conn := utl_smtp.open_connection( mailhost, 25 );
		utl_smtp.helo(mail_conn, mailhost);
		utl_smtp.mail(mail_conn, 'ittraleeck@gmail.com');
		utl_smtp.rcpt(mail_conn, send_email);
		utl_smtp.open_data(mail_conn);
		utl_smtp.write_data(mail_conn,'Hello '||send_username||', a question that you have placed on 
		"ITTralee CK" has been answered. Please check your account to view the answer');
		utl_smtp.close_data(mail_conn);
		utl_smtp.quit(mail_conn);
	END IF;
END;