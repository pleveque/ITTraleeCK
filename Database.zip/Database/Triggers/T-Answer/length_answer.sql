--length_answer.sql--
--If answer is less than 3 characters and greater than 1000 characters an error message will be given--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------

create or replace TRIGGER length_answer
BEFORE INSERT OR UPDATE ON ANSWER
FOR EACH ROW
DECLARE

v_answer_text ANSWER.ANSWER_TEXT%TYPE;
v_errorMessage1 varchar2(255);
v_errorMessage2 varchar2(255);


BEGIN

	v_answer_text := :NEW.ANSWER_TEXT;
	v_errorMessage1 := 'Answer must be greater than 3';
  v_errorMessage2 := 'Answer must be inferior than 1000 characters';

	IF (NOT(LENGTH(v_answer_text) >= 3))
	THEN
		Raise_application_error(-20000, v_errorMessage1);
  ELSE
    IF(NOT(LENGTH(v_answer_text) <= 1000))
    THEN
    	Raise_application_error(-20001, v_errorMessage2);
    END IF;
	END IF;
END;