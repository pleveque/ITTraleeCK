--emailUnique.sql--
--If email is already being used an error message will be given to user--
--Author : Darryl Moynihan--

--------------------------------------------------------------------------------------------

create or replace TRIGGER emailUnique
BEFORE INSERT ON MEMBER
FOR EACH ROW
    WHEN (new.Email is not null)
DECLARE
    num INTEGER;
BEGIN
    SELECT COUNT(*) INTO num 
    FROM member 
    WHERE email =  :new.Email;
If num > 0 THEN
      raise_application_error(-20004,'Email is already in use.');
	END IF;
END;
