--Length_Password.sql--
--If password is inferior than 6 characters and greater than 12 characters it doesn't works--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------


create or replace TRIGGER length_password
BEFORE INSERT OR UPDATE ON MEMBER
FOR EACH ROW
DECLARE

v_password varchar2(255);
v_errorMessage1 varchar2(255);
v_errorMessage2 varchar2(255);


BEGIN

	v_password := :NEW.MEMBERPASSWORD;
	v_errorMessage1 := 'Password must be greater than 6 characters in length';
	v_errorMessage2 := 'Password must be inferior at 12 characters in length';


	IF (LENGTH(v_password) < 6) 
	THEN
		Raise_application_error(-20001, v_errorMessage1);
	ELSE
		IF(LENGTH(v_password) > 12)
		THEN
		Raise_application_error(-20002, v_errorMessage2);
  END IF;
  END IF;
END;