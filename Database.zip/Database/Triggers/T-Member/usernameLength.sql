--usernameLength.sql--
--If username is less than 3 characters greater than 12 charactersâ€™ error message will be given to user--
--Author : Jerome O'connor--

--------------------------------------------------------------------------------------------


create or replace TRIGGER usernameLength
BEFORE INSERT OR UPDATE ON MEMBER
FOR EACH ROW
DECLARE

BEGIN
  IF (LENGTH(:new.Username) < 3) THEN
    raise_application_error(-20001,'Username must be longer than 3 characters');
  ELSE
  IF (LENGTH(:new.Username) > 12) THEN
	raise_application_error(-20002,'Username must be longer than 12 characters');
  END IF;
  END IF;
END;