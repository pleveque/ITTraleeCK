--check_member_mail.sql--
--If age is negative or over 100 an error message will be given to user--
--Author : Antoine CRINQUETTE--


--------------------------------------------------------------------------------------------


create or replace TRIGGER member_mail
BEFORE INSERT OR UPDATE ON MEMBER
FOR EACH ROW
DECLARE


v_mail  varchar2(255);
v_errorMessage varchar2(255);


BEGIN


	v_mail := :NEW.EMAIL;
	v_errorMessage := 'email must be in this form aaa@cccc.dd ';




	IF (NOT(regexp_like(v_mail, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$')))
	THEN
		Raise_application_error(-20000, v_errorMessage);
	END IF;
END;