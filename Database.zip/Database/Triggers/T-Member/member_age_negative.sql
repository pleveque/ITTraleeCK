--check_member_age_negative.sql--
--If age is negative or over 100 an error message will be given to user--
--Author : Antoine CRINQUETTE--


--------------------------------------------------------------------------------------------


create or replace TRIGGER member_age_negative
BEFORE INSERT OR UPDATE ON MEMBER
FOR EACH ROW
DECLARE


v_age number(3,0);
v_errorMessage varchar(255);


BEGIN
	v_age := :NEW.AGE;
	v_errorMessage := 'Age must be between 0 and 100 ';




	IF (v_age < 0 OR v_age > 100)
	THEN
		Raise_application_error(-20000, v_errorMessage);




	END IF;
END;