--Digit_Password.sql--
--If password not contains minimum 1 number it doesn't works--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------


create or replace TRIGGER digit_password
BEFORE INSERT ON MEMBER
FOR EACH ROW
DECLARE

v_password varchar2(255);
v_errorMessage1 varchar2(255);


BEGIN

	v_password := :NEW.MEMBERPASSWORD;
	v_errorMessage1 := 'Password must be contains minimum 1 number';

  IF (NOT(regexp_like(v_password, '[0-9]+')))
	THEN
	  		Raise_application_error(-20001, v_errorMessage1);
	END IF;
END;