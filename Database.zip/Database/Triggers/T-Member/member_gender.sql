--check_member_age_numeric.sql--
--If gender is different than male or female an error message will be given to user--
--Author : Antoine CRINQUETTE--


--------------------------------------------------------------------------------------------
create or replace TRIGGER member_gender
BEFORE INSERT OR UPDATE ON MEMBER
FOR EACH ROW
DECLARE
v_gender varchar2(8);
v_errorMessage varchar2(255);


BEGIN
	v_gender := :NEW.GENDER;
	v_errorMessage := 'Gender must be female or male';


  if not(v_gender like '%ale')
	THEN
		Raise_application_error(-20000, v_errorMessage);
  END IF;
END;