--usernameUnique.sql--
--If username is already being used an error message will be given to user--
--Author : Jerome O'connor--

--------------------------------------------------------------------------------------------


create or replace TRIGGER usernameUnique
BEFORE INSERT ON MEMBER
FOR EACH ROW

	WHEN (new.Username is not null)
  
DECLARE

	num INTEGER;
  
BEGIN

	SELECT COUNT(*) INTO num 
	FROM MEMBER 
	WHERE USERNAME = :new.Username;
    
	IF num > 0 THEN
		raise_application_error(-20003,'Username already exists in the member table');
	END IF;
END;