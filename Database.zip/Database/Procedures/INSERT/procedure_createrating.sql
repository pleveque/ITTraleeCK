--procedure_createrating.sql--
--Procedure to create a rating--
--Author : Pierre Leveque--


--------------------------------------------------------------------------------------------


create or replace PROCEDURE CREATERATING
(
  v_questionID IN RATING.QUESTION_ID%TYPE,
  v_answerID IN RATING.ANSWER_ID%TYPE,
  v_rating IN RATING.RATING%TYPE
)
AS
BEGIN
    
   INSERT INTO RATING(RATING_ID, QUESTION_ID, ANSWER_ID, RATING) 
   VALUES(RATE_SEQ.NEXTVAL, v_questionID, v_answerID, v_rating);
  
END CREATERATING;