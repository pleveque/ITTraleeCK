--procedure_createquestion.sql--
--Procedure who allow a user to create a question--
--Author : Pierre Leveque & Antoine CRINQUETTE--


--------------------------------------------------------------------------------------------

create or replace PROCEDURE CREATEQUESTION
(
  v_memberID IN QUESTION.MEMBER_ID%TYPE,
  v_categoryID IN QUESTION.CATEGORY_ID%TYPE,
  v_questionText IN QUESTION.QUESTION_TEXT%TYPE
)
AS
BEGIN
    
   INSERT INTO QUESTION(QUESTION_ID, MEMBER_ID, CATEGORY_ID, QUESTION_TEXT, QUESTION_DATE) VALUES(QUESTION_SEQ.NEXTVAL, v_memberID, v_categoryID, v_questionText, sysdate);
  
END CREATEQUESTION;