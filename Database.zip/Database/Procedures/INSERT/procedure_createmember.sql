--procedure_createmember.sql--
--Procedure to create a member--
--Author : Pierre Leveque--


--------------------------------------------------------------------------------------------


create or replace PROCEDURE CREATEMEMBER
(
  v_username IN MEMBER.USERNAME%TYPE,
  v_memberPassword IN MEMBER.MEMBERPASSWORD%TYPE,
  v_age IN MEMBER.AGE%TYPE,
  v_email IN MEMBER.EMAIL%TYPE,
  v_gender IN MEMBER.GENDER%TYPE,
  v_nationality IN MEMBER.NATIONALITY%TYPE,
  v_categoryKnowledge IN MEMBER.CATEGORY_OF_KNOWLEDGE%TYPE,
  v_newsletter IN MEMBER.NEWSLETTER%TYPE,
  v_typeOfMember IN MEMBER.TYPE_OF_MEMBER%TYPE
)
AS
BEGIN
    
   INSERT INTO MEMBER(MEMBER_ID, USERNAME, MEMBERPASSWORD, AGE, EMAIL, GENDER, NATIONALITY, CATEGORY_OF_KNOWLEDGE, NEWSLETTER, TYPE_OF_MEMBER) 
   VALUES(MEMBER_SEQ.NEXTVAL, v_username, v_memberPassword, v_age, v_email, v_gender, v_nationality, v_categoryKnowledge, v_newsletter, v_typeOfMember);
  
END CREATEMEMBER;