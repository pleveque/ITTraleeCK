--procedure_createanswer.sql--
--Procedure to create a answer--
--Author : Pierre Leveque--


--------------------------------------------------------------------------------------------


create or replace PROCEDURE CREATEANSWER
(
  v_questionID IN ANSWER.QUESTION_ID%TYPE,
  v_memberID IN ANSWER.MEMBER_ID%TYPE,
  v_answerText IN ANSWER.ANSWER_TEXT%TYPE
)
AS
BEGIN
    
   INSERT INTO ANSWER(ANSWER_ID, QUESTION_ID, MEMBER_ID, ANSWER_TEXT, ANSWER_DATE) 
   VALUES(ANSWER_SEQ.NEXTVAL, v_questionID, v_memberID, v_answerText, sysdate);
  
END CREATEANSWER;