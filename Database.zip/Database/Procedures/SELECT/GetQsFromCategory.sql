create or replace PROCEDURE getQsfromCategory(
  p_CategoryID IN QUESTION.category_id%TYPE,
  o_QuestionTxt OUT QUESTION.Question_Text%TYPE,
  o_Qdate OUT  QUESTION.Question_Date%TYPE,
  o_MemberID OUT QUESTION.member_id%TYPE)
AS
BEGIN 
      Select question_text, question_date, member_ID
      INTO o_QuestionTxt,o_Qdate, o_MemberID
      from question WHERE Category_ID = p_categoryID
      ORDER BY QUESTION_DATE;
END;