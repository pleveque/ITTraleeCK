create or replace PROCEDURE getAnswersByQuestionID(
     p_questionID IN ANSWER.Question_ID%TYPE,
     o_answerID OUT ANSWER.Answer_ID%TYPE,
     o_memberID OUT ANSWER.Member_ID%TYPE,
     o_answerText OUT ANSWER.Answer_Text%TYPE,
     o_answerDate OUT ANSWER.Answer_Date%TYPE)
AS
BEGIN
      Select Answer_ID, Member_ID, Answer_Text, Answer_Date
      INTO o_answerID, o_memberID,o_answerText,o_answerDate
      FROM Answer WHERE Question_ID = p_questionID
      ORDER BY Answer_Date;
END;
