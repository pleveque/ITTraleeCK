create or replace PROCEDURE getAllAnswersByMember(
     p_memberID IN ANSWER.Member_ID%TYPE,
     o_answerID OUT ANSWER.Answer_ID%TYPE,
     o_questionID OUT ANSWER.Question_ID%TYPE,
     o_answerText OUT ANSWER.Answer_Text%TYPE,
     o_answerDate OUT ANSWER.Answer_Date%TYPE)
AS
BEGIN
      Select Answer_ID, Question_ID, Answer_Text, Answer_Date
      INTO o_answerID, o_questionID,o_answerText,o_answerDate
      FROM Answer WHERE Member_ID = p_memberID
      ORDER BY Answer_Date;
END;