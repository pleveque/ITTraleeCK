create or replace PROCEDURE getQsbyDate(
  p_Qdate IN QUESTION.question_date%TYPE,
  o_QuestionTxt OUT QUESTION.Question_Text%TYPE,
  o_question_ID OUT  QUESTION.Question_ID%TYPE,
  o_MemberID OUT QUESTION.member_id%TYPE)
AS
BEGIN 
      Select question_text, question_ID, member_ID
      INTO o_QuestionTxt,o_Question_ID, o_MemberID
      from question
      ORDER BY question_Date ASC;
END;