create or replace PROCEDURE getQsFromMember(
  p_MemberID IN QUESTION.member_ID%TYPE,
  o_QuestionTxt OUT QUESTION.Question_Text%TYPE,
  o_Qdate OUT  QUESTION.Question_Date%TYPE,
  o_QuestionID OUT QUESTION.question_id%TYPE)
AS
BEGIN 
      Select question_text,Question_date,question_ID
      INTO o_QuestionTxt,o_Qdate,o_QuestionID 
      from question WHERE member_ID = p_MemberID
	  ORDER BY question_date;
END;