--rate_seq.sql--
--Sequence for id to rate a answer--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------

DROP SEQUENCE RATE_SEQ;


CREATE SEQUENCE RATE_SEQ
INCREMENT BY 1
START WITH 6
MINVALUE 5
CACHE 20;
