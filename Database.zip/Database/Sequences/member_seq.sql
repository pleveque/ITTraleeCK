--member_seq.sql--
--Sequence for id member --
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------

DROP SEQUENCE MEMBER_SEQ;


CREATE SEQUENCE MEMBER_SEQ
INCREMENT BY 1
START WITH 20
MINVALUE 19
CACHE 20;