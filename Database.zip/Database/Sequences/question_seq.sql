--question_seq.sql--
--Sequence for id to post a question--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------

DROP SEQUENCE QUESTION_SEQ;


CREATE SEQUENCE QUESTION_SEQ
INCREMENT BY 1
START WITH 10
MINVALUE 9
CACHE 20;
