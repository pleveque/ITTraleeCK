--answer_seq.sql--
--Sequence for the id to post a answer--
--Author : Pierre Leveque--

--------------------------------------------------------------------------------------------

DROP SEQUENCE ANSWER_SEQ;


CREATE SEQUENCE ANSWER_SEQ
INCREMENT BY 1
START WITH 10
MINVALUE 9
CACHE 20;
