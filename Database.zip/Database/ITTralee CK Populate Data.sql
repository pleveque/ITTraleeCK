INSERT INTO Member
VALUES (0001,'JeromeOCo','admin1',21,'Jerome.OConnor@students.ittralee.ie','Male','Irish','Computing','y','Admin');
INSERT INTO Member
VALUES (0002,'AntoineCri','admin2',20,'antoine.crinquette@students.ittralee.ie','Male','French','Computing','n','Admin');
INSERT INTO Member
VALUES (0003,'DarrylMoy','admin3',24,'darryl.moynihan@students.ittralee.ie','Male','Irish','Computing','y','Admin');
INSERT INTO Member
VALUES (0004,'PierreLev','admin4',20,'pierre.leveque@students.ittralee.ie','Male','French','Business','n','Admin');
INSERT INTO Member
VALUES (0005,'user1','user001',36,'user1@students.ittralee.ie','Male','Irish','Nursing','y','User');
INSERT INTO Member
VALUES (0006,'user2','user002',48,'user2@students.ittralee.ie','Female','Irish','Business','y','User');
INSERT INTO Member
VALUES (0007,'user3','user003',21,'user3@students.ittralee.ie','Female','Irish','Tourism','y','User');



INSERT INTO Category
VALUES (0001,'Creative Media');
INSERT INTO Category
VALUES (0002,'Computing');
INSERT INTO Category
VALUES (0003,'Business');
INSERT INTO Category
VALUES (0004,'Tourism');
INSERT INTO Category
VALUES (0005,'Agricultural Engineering');
INSERT INTO Category
VALUES (0006,'Civil Engineering');
INSERT INTO Category
VALUES (0007,'Construction Studies');
INSERT INTO Category
VALUES (0008,'Biological Studies');
INSERT INTO Category
VALUES (0009,'Pharmaceutical Studies');
INSERT INTO Category
VALUES (0010,'Nursing');
INSERT INTO Category
VALUES (0011,'Social Sciences');
INSERT INTO Category
VALUES (0012,'Health and Leisure Studies');



INSERT INTO Question
VALUES (0001,0001,0002,'What does the term method overloading mean?',sysdate);
INSERT INTO Question
VALUES (0002,0003,0010,'What is the best way to check a heart beat?',sysdate);
INSERT INTO Question
VALUES (0003,0005,0008,'How do plants use sublight to generate food?',sysdate);
INSERT INTO Question
VALUES (0004,0002,0004,'What are the best tourism spots in Ireland?',sysdate);
INSERT INTO Question
VALUES (0005,0004,0003,'How to calculate income tax?',sysdate);



INSERT INTO Answer
VALUES (0001,0001,0002,'Method Overloading is a feature that allows a class to have two or more methods having same name, if their argument lists are different.',sysdate);
INSERT INTO Answer
VALUES (0002,0005,0001,'Tax is calculated at the standard rate of 20% on your gross pay up to the amount of your weekly standard rate cut-off point.  
Any balance of gross pay above the standard rate cut-off point is taxed at the higher tax rate of 40%. The tax calculated at 20% is added to the tax 
calculated at 40% to arrive at your gross tax figure. The gross tax figure is then reduced by the amount of your tax credits to arrive at your tax payable in that week',sysdate);
INSERT INTO Answer
VALUES (0003,0004,0003,'Killarney, Galway, Dublin',sysdate);
INSERT INTO Answer
VALUES (0004,0003,0004,'Photosynphis',sysdate);
INSERT INTO Answer
VALUES (0005,0002,0005,'Via the veins on the neck',sysdate);



INSERT INTO Rating
VALUES (0001,0001,null,23);
INSERT INTO Rating
VALUES (0002,0004,0003,10);
INSERT INTO Rating
VALUES (0003,0003,0004,46);
INSERT INTO Rating
VALUES (0004,0002,null,-2);